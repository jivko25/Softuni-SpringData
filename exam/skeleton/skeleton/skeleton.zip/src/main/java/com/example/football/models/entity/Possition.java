package com.example.football.models.entity;

public enum Possition {
    ATT, MID, DEF
}
