package com.example.springautomappingobjects.model.entity;

public enum Role {
    ADMIN, USER
}
